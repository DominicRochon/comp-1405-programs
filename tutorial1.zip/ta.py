#This is a comment made by Dominic Rochon! :D
print('Carter')
print('Micheal')
print('Nathaniel')
print('Shrish')
print('Steven')